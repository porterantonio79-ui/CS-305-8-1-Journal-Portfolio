package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SslServerApplication.class, args);
    }
}

@RestController
class ChecksumController {

    @GetMapping("/hash")
    public String getChecksum() throws Exception {
        
        String data = "Antonio Porter - CS305 - Unique String 2026";
        String checksum = calculateSHA256(data);
        return "<h1>SHA-256 Checksum Verification</h1>"
             + "<p><strong>Name:</strong> Antonio Porter</p>"
             + "<p><strong>Data String:</strong> " + data + "</p>"
             + "<p><strong>SHA-256 Checksum:</strong> " + checksum + "</p>";
    }

    private String calculateSHA256(String data) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
}